export const endpoint = "https://api.made.quixoria.ru/";
